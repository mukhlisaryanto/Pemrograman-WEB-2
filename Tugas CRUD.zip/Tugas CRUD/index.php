<?php
// Nama   : Mukhlis Aryanto
// NIM    : 181011450299
// Kelas  : 06TPLE005

//Koneksi Database

$server = "localhost";
$user = "root";
$pass = "";
$database = "dbtugas15";
$koneksi = mysqli_connect($server, $user , $pass, $database) or die(mysqli_error($koneksi));

//jika tombol simpan di klik
if(isset($_POST['bsimpan']))
{
  //Pengujian Apakah Data Akan Di Edit atau disimpan Baru
  if($_GET['hal'] == "edit")
  {
    //Data Akan Di Edit
    $edit = mysqli_query($koneksi, "UPDATE mhs set
                                    nim = '$_POST[tnim]',
                                    nama = '$_POST[tnama]',
                                    alamat = '$_POST[talamat]',
                                    prodi = '$_POST[tprodi]'

                                    WHERE id_mhs = '$_GET[id]'
    ");
  
        if($edit)//Jika Edit Sukses
        {
          echo "<script>
          alert('Edit data sukses!');
          document.location='index.php';
          </script>";
        }
        else
        {
          echo "<script>
          alert('Edit data GAGAL!');
          document.location='index.php';
          </script>";
        }
  }else
  {
    //Data Akan Disimpan Baru

    $simpan = mysqli_query($koneksi, "INSERT INTO mhs(nim, nama, alamat, prodi) 
    VALUES ( '$_POST[tnim]',
            '$_POST[tnama]',
            '$_POST[talamat]',
            '$_POST[tprodi]')
    ");
  
        if($simpan)//Jika Simpan Sukses
        {
          echo "<script>
          alert('simpan data sukses!');
          document.location='index.php';
          </script>";
        }
        else
        {
          echo "<script>
          alert('simpan data GAGAL!');
          document.location='index.php';
          </script>";
        }
  }


}

//Pengujian Jika tombol Edit/Hapus di klik
if(isset($_GET['hal']))
{
  //Pengujian Jika Edit Data
  if($_GET['hal']=="edit")
  {
    //Tampilkan Data Yang Akan Di edit
    $tampil = mysqli_query($koneksi, "SELECT * FROM mhs WHERE id_mhs = '$_GET[id]'");
    $data = mysqli_fetch_array($tampil);
    if($data)
    {
      //Jika data ditemukan, maka data ditampung ke dalam varibel
      $vnim = $data['nim'];
      $vnama = $data['nama'];
      $valamat = $data['alamat'];
      $vprodi = $data['prodi'];
    }
  }
  else if ($_GET['hal'] =="hapus")
  {
    //Persiapan Hapus Data
    $hapus = mysqli_query($koneksi, "DELETE FROM mhs WHERE id_mhs = '$_GET[id]' ");
    if($hapus){
      echo "<script>
          alert('Hapus data Sukses!');
          document.location='index.php';
          </script>";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas Terstruktur 15 CRUD</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container">
<h1 class="text-center  fw-bold">Tugas Terstruktur 15 CRUD </h1>
<h4 class="text-center"> Nama : Mukhlis Aryanto</h2>
<h4 class="text-center"> Nim : 181011450299</h2>
<h4 class="text-center"> Kelas : 06TPLE005</h2>

<!-- awal Form card-->
<div class="card mt-3">
  <div class="card-header bg-warning">
    Form Input Data Mahasiswa
  </div>
  <div class="card-body">
<form method="post" action="">
    <div class="form-group">
        <label>Nim</label>
        <input type="text" name="tnim" value="<?=@$vnim?>" class="form-control" placeholder="Input Nim Kamu" required>
    </div>
    <div class="form-group">
        <label>Nama</label>
        <input type="text" name="tnama" value="<?=@$vnama?>" class="form-control" placeholder="Input Nama Kamu" required>
    </div>
    <div class="form-group">
        <label>Alamat</label>
        <textarea class="form-control" name="talamat" placeholder="Input Alamat Kamu" required><?=@$valamat?></textarea>
    </div>
    <div class="form-group">
        <label>Program Studi</label>
      <select class="form-control" name="tprodi" required> 
          <option value="<?=@$vprodi?>"><?=@$vprodi?></option>
          <option value="S1-Sistem Informasi">S1-Sistem Informasi</option>
          <option value="S1-Manajemen Informatika">S1-Manajemen Informatika</option>
          <option value="S1-Teknik Informatika">S1-Teknik Informatika</option>
      </select>
    </div>

    <button type="submit" class="btn btn-success mt-3" name="bsimpan">Simpan</button>
    <button type="reset" class="btn btn-danger mt-3" name="breset">Kosongkan</button>
</form>
  </div>
</div>
<!-- akhir Form card-->

<!-- Awal Table card-->
<div class="card mt-3">
  <div class="card-header bg-primary  text-white">
   Daftar Mahasiswa
  </div>
  <div class="card-body">
      <table class="table table-borderd table-striped">
          <tr>
              <th>No.</th>
              <th>Nim</th>
              <th>Nama</th>
              <th>Alamat</th>
              <th>Program Studi</th>
              <th>Aksi</th>
          </tr>
            <?php
            $no = 1;
            $tampil = mysqli_query($koneksi, "SELECT * from mhs order by id_mhs desc");
            while($data = mysqli_fetch_array($tampil)):
            ?>

          <tr>
              <td><?=$no++;?></td>
              <td><?=$data["nim"]?></td>
              <td><?=$data["nama"]?></td>
              <td><?=$data["alamat"]?></td>
              <td><?=$data["prodi"]?></td>
              <td>
                <a href="index.php?hal=edit&id=<?=$data['id_mhs']?>" class="btn btn-warning">Edit</a>
                <a href="index.php?hal=hapus&id=<?=$data['id_mhs']?>" onclick="return confirm('Apakah Yakin Ingin Menghapus Data Ini?')" class="btn btn-danger">Hapus</a>
              </td>
          </tr>
          <?php endwhile; //penutup perulangan while?>
      </table>

  </div>
</div>
<!-- akhir table card-->

</div>
<script src="js/bootstrap.min.js"></script>
</body>
</html>

<!-- 
//Nama   : Mukhlis Aryanto
// NIM    : 181011450299
// Kelas  : 06TPLE005
-->